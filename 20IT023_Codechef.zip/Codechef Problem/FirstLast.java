/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class FirstLast
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
		
		Scanner sc= new Scanner(System.in);
		int t=sc.nextInt();
		for(int j=0;j<t;j++)
		{
		int num= sc.nextInt();
		int reverse= 0;
		int last= num%10;
		int remain;
		for (int i=0;num>0 ;i++ )
		{
		    remain= num%10;
		    reverse= reverse*10+remain;
		    num=num/10;
		}
		int first = reverse%10;
		int sum= last+first;
		System.out.println(sum);
		}
	}
}