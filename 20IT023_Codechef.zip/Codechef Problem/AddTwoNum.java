import java.util.Scanner;
public class AddTwoNum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	//	System.out.print("Enter test case : ");
		int n = sc.nextInt();
		for(int i = 0; i<n;i++) {
		//	System.out.print("Enter first num : ");
			int num1 = sc.nextInt();
		//	System.out.print("Enter second num : ");
			int num2 = sc.nextInt();
			int sum = num1 + num2 ;
			System.out.println(sum);
		}
		sc.close();
	}

}