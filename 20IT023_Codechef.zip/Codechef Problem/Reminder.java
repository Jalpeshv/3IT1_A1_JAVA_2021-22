import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Reminder
{
    public static void main(String args[])
    {
        Scanner s = new Scanner(System.in);
        int z = s.nextInt();
        for(int i=0;i<z;i++)
        {
            int a = s.nextInt();
            int b = s.nextInt();
            int result = a % b;
            System.out.println(result);
        }

    }


}