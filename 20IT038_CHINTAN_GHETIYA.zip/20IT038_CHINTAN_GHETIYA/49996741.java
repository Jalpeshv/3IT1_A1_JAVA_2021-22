import java.io.*;
class PROBOBAL {
    
    
	public static void main(String[] args)throws IOException {
	    
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t=Integer.parseInt(br.readLine()),n=0,j=0,l=0,c=0,c1=0;
		double d=0;
		
		for(int i=1;i<=t;i++)
		{
			n=Integer.parseInt(br.readLine());
			c=0;
			while(n!=0)
			{
			    j=n%10;
			    if(j==4)
			    c++;
			    n/=10;
			}
			System.out.println(c);
		}
	}
}