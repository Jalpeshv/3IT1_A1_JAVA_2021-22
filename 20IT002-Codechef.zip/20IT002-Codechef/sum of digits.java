/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Codechef
{
	public static void main (String[] args) throws java.lang.Exception
	{
	    Scanner scan = new Scanner(System.in);
        int t = scan.nextInt();
        for(int i=0;i<t;i++)
        {
            int z = scan.nextInt();
            int sum = 0;
            while(z>0)
            {
                int rev;

                rev = z % 10;
                sum = sum + rev;
                z = z/10;


            }
            System.out.println(sum);
        }
	    
		// your code goes here
	}
}
