import java.util.*;
class Codechef
{
	public static void main (String[] args) 
	{
		Scanner sc = new Scanner(System.in); 
		int t= sc.nextInt();
		int l,f;
		while(t>0)
		{
		    int n=sc.nextInt();
		    l=n%10;
		    f=firstDigit(n);
		    System.out.println(l+f);
	        t--;
        }
		    
	}
	    static	int firstDigit(int n){
        while (n >=
        10)
        n /= 10;
        return n;
	    
	}
}