/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Codechef 
{
	public static void main (String[] args) throws java.lang.Exception
	{
		int lead=0;
		int winner=1;
		int temp=0;
		int first=0;
			int second=0;
			
		Scanner sc=new Scanner(System.in);
			
		int rounds=sc.nextInt();
			
		for(int i=0;i<rounds;i++)
		{
			first+=sc.nextInt();
			second+=sc.nextInt();
				
			if(first>second)
			{
			    temp=first-second;
				if(temp>lead)
				{
					lead=temp;
					winner=1;
				}
			}
				else
			{
				temp=second-first;
				if(temp>lead)
				{
					lead=temp;
					winner=2;
				}
			}
		}
	    System.out.println(winner + " " + lead);
	}
}

