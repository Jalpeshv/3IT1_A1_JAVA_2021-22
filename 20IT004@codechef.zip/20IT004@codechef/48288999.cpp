#include <bits/stdc++.h>
#define ll long long int
#define debug(x) cout<<x<<"\n"
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    ll t;cin>>t;
    while(t--){
        unordered_map<string,int>MAP;
        ll n;cin>>n;
        for(ll i = 0; i < n*3; i++){
            string s;
            ll sol;
            cin>>s>>sol;
            if(MAP.find(s) != MAP.end()){
                MAP[s] += sol;
            }
            else{
                MAP.insert({s,sol});
            }
        }
        vector<ll>ans;
        for(auto i : MAP){
            ans.push_back(i.second);
        }
        sort(ans.begin(),ans.end());
        for(ll i = 0; i < ans.size(); i++){
            cout<<ans[i]<<" ";
        }
        cout<<'\n';
    }
    
    return 0;
}
