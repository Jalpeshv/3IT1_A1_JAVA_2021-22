#include <bits/stdc++.h>
#define ll long long int
#define debug(x) cout<<x<<"\n"
#define mod 1000000007
using namespace std;

ll Power(ll x, ll y, ll p){
    ll res = 1;
    x = x % p;
    if(x == 0)
        return 0;
        
    while(y > 0){
        if(y % 2 != 0){
            res = (res * x) % p;
        }
        y /= 2;
        x = (x*x) % p;
    }
    return res;
}

int main() {
	ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    
    ll q,l,r;
    cin>>q;
    vector<ll>chefora(100002);
    vector<ll>prefixsum(100002);
    chefora[0] = 0;
    prefixsum[0] = 0;
    for(ll i = 1; i < 100001; i++){
        ll num = i, temp = i;
        num /= 10;
        while(num > 0){
            temp = ((temp * 10) + (num % 10));
            num /= 10;
        }
        chefora[i] = temp;
        prefixsum[i] = prefixsum[i-1] + temp;
    }
    while(q--){
        cin>>l>>r;
        ll power = prefixsum[r] - prefixsum[l];
        ll base = chefora[l];
        //debug(power);
        //debug(base);
        cout<<Power(base, power, mod)<<"\n";
    }
    return 0;
}
