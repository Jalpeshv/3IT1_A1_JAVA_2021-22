#include <bits/stdc++.h>
#define ll long long int
#define debug(x) cout<<x<<"\n"
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
     ll t;
    cin>>t;
    while(t--){
       ll n,k;
       cin>>n>>k;
       ll a[n];
       for(ll i = 0; i < n; i++){
             cin>>a[i];
       }
       vector<ll>Sum1(65,0);
       ll count = 0;
       for(ll i = 0; i<=32; i++){
             count = 0;
             for(ll j = 0; j < n; j++){
                if(a[j] % 2 != 0){
                    count++;
                }
                a[j] /= 2;
            }
            Sum1[i] = count;
        }
        ll ans = 0;
        for(ll i = 0; i<=32; i++){
             if(Sum1[i] % k == 0){
                ans += Sum1[i] / k;
            }
            else{
                ans += Sum1[i] / k + 1; 
            }
       }
       cout<<ans<<"\n";
    }
    return 0;
}
