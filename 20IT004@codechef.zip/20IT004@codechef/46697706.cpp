#include <iostream>
using namespace std;

int main() {
	// your code goes here
	int t;
	cin>>t;
	for(int i=0; i<t; i++)
	{
	    int activities;
        string origin;
        string work;
        int rank = 20, severity, laddus = 0;

        cin>>activities>>origin;
    
        while(activities--)
        {
            cin>>work;
            if(work=="TOP_CONTRIBUTOR")
            {
                laddus += 300;
            }
            else if(work=="CONTEST_HOSTED")
            {
                laddus += 50;
            }
            else if(work=="CONTEST_WON")
            {
                cin>>rank;
                if(rank<=20)
                {
                    laddus+=(20-rank);
                }
                laddus += 300;
            }
            else if(work=="BUG_FOUND")
            {
                cin>>severity;
                laddus += severity;
            }
        }
        if(origin=="INDIAN")
        {
            cout<<laddus/200<<endl;
        }
        else
        {
            cout<<laddus/400<<endl;
        }
	}
	return 0;
}
