#include <bits/stdc++.h>
#define ll long long int
#define debug(x) cout<<x<<"\n"
using namespace std;
int main() {
	ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    ll t;cin>>t;
    while(t--){
        ll n,h,count=0;
        cin>>n>>h;
        string s;
        cin>>s;
        for(ll i=0; i<n; i++){
            if(s[i]=='0'){
                count++;
            }
            else{
                if(count >= h){
                    break;
                }
                else{
                    if(i != 0 && i!=n-1){
                        h =min(h, 2*(h-count));
                        count = 0;
                    }
                }
            }
        }
        if(count >= h){
            cout<<"YES\n";
        }
        else{
            cout<<"NO\n";
        }
    }
    
    return 0;
}